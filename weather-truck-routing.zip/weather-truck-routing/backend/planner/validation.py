"""Request parsing/validation for POST /api/analyze."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from .errors import ApiError

ALLOWED_INTERVALS = (10, 25, 50)
MAX_LOAD_LB = 150_000


@dataclass(frozen=True)
class AnalyzeRequest:
    origin: dict
    destination: dict
    departure: datetime  # timezone-aware, UTC
    load_lb: float
    interval_miles: int


def _place(body: dict, name: str) -> dict:
    spec = body.get(name)
    if not isinstance(spec, dict):
        raise ApiError(f"'{name}' is required.")
    has_coords = spec.get("lat") is not None and spec.get("lon") is not None
    if has_coords:
        try:
            lat, lon = float(spec["lat"]), float(spec["lon"])
        except (TypeError, ValueError):
            raise ApiError(f"'{name}' has invalid coordinates.") from None
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            raise ApiError(f"'{name}' coordinates are out of range.")
    elif not str(spec.get("query") or "").strip():
        raise ApiError(f"Enter a {name}.")
    return spec


def parse_analyze_request(body: object, now: datetime | None = None) -> AnalyzeRequest:
    if not isinstance(body, dict):
        raise ApiError("Request body must be a JSON object.")
    now = now or datetime.now(timezone.utc)

    raw = body.get("departure")
    try:
        departure = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
    except ValueError:
        raise ApiError("'departure' must be an ISO 8601 date/time.") from None
    if departure.tzinfo is None:
        departure = departure.replace(tzinfo=timezone.utc)
    departure = departure.astimezone(timezone.utc)
    if departure < now - timedelta(hours=24):
        raise ApiError("Departure can't be more than 24 hours in the past.")
    if departure > now + timedelta(days=13):
        raise ApiError("Departure must be within the next 13 days (the forecast horizon).")

    try:
        load = float(body.get("load_weight_lb"))
    except (TypeError, ValueError):
        raise ApiError("'load_weight_lb' must be a number.") from None
    if not (0 <= load <= MAX_LOAD_LB):
        raise ApiError(f"Load weight must be between 0 and {MAX_LOAD_LB:,} lb.")

    try:
        interval = int(body.get("interval_miles", 25))
    except (TypeError, ValueError):
        raise ApiError("'interval_miles' must be 10, 25 or 50.") from None
    if interval not in ALLOWED_INTERVALS:
        raise ApiError("'interval_miles' must be 10, 25 or 50.")

    return AnalyzeRequest(_place(body, "origin"), _place(body, "destination"), departure, load, interval)
