"""Per-route exposure summaries, ranking and the human-readable explanation."""
from __future__ import annotations

from typing import Sequence

from .risk import Risk

# Order matters: the first differing criterion decides. The brief lists
# Severe -> High -> average risk -> time. We add "No Travel miles" in front:
# a route that crosses No Travel conditions is not drivable at that time, so
# it must lose to any route that does not.
CRITERIA = (
    ("no_travel_miles", "No Travel miles", 0),
    ("severe_miles", "Severe miles", 0),
    ("high_miles", "High-risk miles", 0),
    ("avg_risk", "average risk score", 2),
    ("duration_minutes", "travel time", 0),
)


def segment_bounds(miles: Sequence[float], total_miles: float) -> list[tuple[float, float]]:
    """Each checkpoint 'owns' the stretch halfway to its neighbours (ends clamp to the route)."""
    n = len(miles)
    bounds = []
    for i, m in enumerate(miles):
        start = 0.0 if i == 0 else (miles[i - 1] + m) / 2
        end = total_miles if i == n - 1 else (m + miles[i + 1]) / 2
        bounds.append((start, end))
    return bounds


def summarize(levels: Sequence[Risk], bounds: Sequence[tuple[float, float]]) -> dict:
    by_level = {r.name.lower(): 0.0 for r in Risk}
    weighted = 0.0
    total = 0.0
    for level, (start, end) in zip(levels, bounds):
        length = max(0.0, end - start)
        by_level[Risk(level).name.lower()] += length
        weighted += int(level) * length
        total += length
    worst = max(levels) if levels else Risk.LOW
    return {
        "miles_by_level": {k: round(v, 1) for k, v in by_level.items()},
        "no_travel_miles": round(by_level["no_travel"], 1),
        "severe_miles": round(by_level["severe"], 1),
        "high_miles": round(by_level["high"], 1),
        "avg_risk": round(weighted / total, 3) if total else 0.0,
        "worst_level": int(worst),
        "worst_label": Risk(worst).label,
    }


def _metrics(route: dict) -> tuple:
    s = route["summary"]
    values = {**s, "duration_minutes": route["duration_minutes"]}
    return tuple(round(values[key], digits) for key, _, digits in CRITERIA)


def rank_routes(routes: list[dict]) -> list[dict]:
    """Best first. Metrics are rounded (1 mile / 0.01 risk / 1 minute) so noise can't flip a rank."""
    return sorted(routes, key=_metrics)


def explain(ranked: list[dict]) -> list[str]:
    """Explain the winner in terms of the first criterion that separates it from each rival."""
    winner = ranked[0]
    w = _metrics(winner)
    reasons: list[str] = []
    s = winner["summary"]
    if len(ranked) == 1:
        return [f"{winner['name']} is the only route available."]
    if s["no_travel_miles"] == 0 and s["severe_miles"] == 0 and s["high_miles"] == 0:
        reasons.append(f"{winner['name']} has no High, Severe or No Travel weather on its forecast.")
    else:
        reasons.append(
            f"{winner['name']} has the least dangerous weather exposure of the options."
        )
    for other in ranked[1:]:
        o = _metrics(other)
        for idx, (key, label, digits) in enumerate(CRITERIA):
            if o[idx] == w[idx]:
                continue
            diff = o[idx] - w[idx]
            if key == "duration_minutes":
                text = f"{other['name']} is {diff:.0f} min slower with the same weather exposure."
            elif key == "avg_risk":
                text = (
                    f"{other['name']} has a higher average risk score "
                    f"({o[idx]:.2f} vs {w[idx]:.2f})."
                )
            else:
                text = f"{other['name']} has {diff:.0f} more {label}."
            reasons.append(text)
            break
        else:
            reasons.append(f"{other['name']} is identical on every criterion.")
    return reasons
