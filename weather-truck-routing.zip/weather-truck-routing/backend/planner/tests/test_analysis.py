"""End-to-end test of the analysis pipeline with fake routing + weather providers."""
import sys
import types
import unittest
from datetime import date, datetime, timedelta, timezone

try:  # use real Django settings when available, a stub otherwise
    from django.conf import settings

    if not settings.configured:
        settings.configure(TRUCK_DURATION_FACTOR=1.0, MAX_CHECKPOINTS_PER_ROUTE=150)
except ImportError:  # pragma: no cover
    fake_settings = types.SimpleNamespace(TRUCK_DURATION_FACTOR=1.0, MAX_CHECKPOINTS_PER_ROUTE=150)
    conf = types.ModuleType("django.conf")
    conf.settings = fake_settings
    sys.modules.setdefault("django", types.ModuleType("django"))
    sys.modules["django.conf"] = conf

from planner import geo
from planner.analysis import Providers, analyze_trip
from planner.osrm import RawRoute
from planner.validation import AnalyzeRequest
from planner.weather import HourlySeries, point_key

DEPARTURE = datetime(2026, 11, 2, 6, 0, tzinfo=timezone.utc)


def straight_route(lat_offset, miles=200.0, mph=60.0):
    """West->east line at latitude `lat_offset`, with constant speed."""
    n = 201
    total_deg = miles / 69.0
    coords = [(40.0 + lat_offset, -100.0 + total_deg * i / (n - 1)) for i in range(n)]
    cum_m = geo.cumulative_haversine(coords)
    scale = miles * geo.METERS_PER_MILE / cum_m[-1]
    cum_m = [c * scale for c in cum_m]
    dur = miles / mph * 3600
    cum_s = [c / cum_m[-1] * dur for c in cum_m]
    return RawRoute(coords, cum_m, cum_s, cum_m[-1], dur)


def make_weather(storm_lat):
    """Calm everywhere except latitudes near `storm_lat`, where wind is 48 mph all day."""
    def fetch(points, start, end):
        hours = ((end - start).days + 1) * 24
        t0 = datetime(start.year, start.month, start.day, tzinfo=timezone.utc)
        out = {}
        for lat, lon in points:
            k = point_key(lat, lon)
            wind = 48.0 if abs(k[0] - storm_lat) < 0.3 else 8.0
            out[k] = HourlySeries(t0, (wind,) * hours, (0.0,) * hours, (0.0,) * hours)
        return out
    return fetch


class PipelineTests(unittest.TestCase):
    def providers(self, storm_lat):
        routes = [straight_route(0.0, mph=65), straight_route(1.0, miles=215, mph=62), straight_route(2.0, miles=230, mph=62)]
        return Providers(
            resolve_place=lambda spec, field: {"label": spec["query"], "lat": 40.0, "lon": -100.0 if spec["query"] == "A" else -97.0},
            get_routes=lambda o, d, f: routes,
            fetch_weather=make_weather(storm_lat),
        )

    def request(self, load):
        return AnalyzeRequest({"query": "A"}, {"query": "B"}, DEPARTURE, load, 25)

    def test_heavy_load_avoids_windy_corridor(self):
        # Fastest route (lat 40.0) runs through 48 mph wind; heavy load => No Travel there.
        result = analyze_trip(self.request(load=60_000), self.providers(storm_lat=40.0))
        by_id = {r["id"]: r for r in result["routes"]}
        self.assertGreater(by_id["route-1"]["summary"]["no_travel_miles"], 0)
        self.assertEqual(by_id["route-2"]["summary"]["worst_label"], "Low")
        self.assertNotEqual(result["recommendation"]["route_id"], "route-1")

    def test_light_load_same_wind_is_severe_not_blocked(self):
        result = analyze_trip(self.request(load=20_000), self.providers(storm_lat=40.0))
        r1 = next(r for r in result["routes"] if r["id"] == "route-1")
        self.assertEqual(r1["summary"]["no_travel_miles"], 0)
        self.assertGreater(r1["summary"]["severe_miles"], 190)

    def test_calm_weather_recommends_fastest(self):
        result = analyze_trip(self.request(load=40_000), self.providers(storm_lat=-80.0))
        self.assertEqual(result["recommendation"]["route_id"], "route-1")
        self.assertTrue(next(r for r in result["routes"] if r["recommended"])["id"], "route-1")

    def test_response_shape(self):
        result = analyze_trip(self.request(load=40_000), self.providers(storm_lat=-80.0))
        r = result["routes"][0]
        cps = r["checkpoints"]
        self.assertEqual([c["mile"] for c in cps][:3], [0.0, 25.0, 50.0])
        self.assertEqual(cps[-1]["mile"], r["distance_miles"])
        self.assertEqual(cps[0]["eta"], "2026-11-02T06:00:00Z")
        eta1 = datetime.fromisoformat(cps[1]["eta"].replace("Z", "+00:00"))
        self.assertAlmostEqual((eta1 - DEPARTURE).total_seconds() / 3600, 25 / 65, places=2)
        self.assertEqual(len(cps[0]["forecast"]["levels"]), 49)
        self.assertEqual(r["segments"][0]["from_mile"], 0.0)
        self.assertAlmostEqual(r["segments"][-1]["to_mile"], r["distance_miles"], places=1)
        self.assertEqual(sum(r["summary"]["miles_by_level"].values()), r["distance_miles"])

    def test_eta_selects_forecast_hour(self):
        """A storm that starts at 08:00 UTC must hit checkpoints reached after 08:00 only."""
        def fetch(points, start, end):
            t0 = datetime(start.year, start.month, start.day, tzinfo=timezone.utc)
            hours = ((end - start).days + 1) * 24
            wind = tuple(50.0 if h >= 8 else 5.0 for h in range(hours))  # from 08:00 on
            return {point_key(*p): HourlySeries(t0, wind, (0.0,) * hours, (0.0,) * hours) for p in points}
        p = self.providers(-80.0)
        p.fetch_weather = fetch
        cps = analyze_trip(self.request(load=10_000), p)["routes"][0]["checkpoints"]
        for c in cps:
            eta = datetime.fromisoformat(c["eta"].replace("Z", "+00:00"))
            hour = round((eta - DEPARTURE.replace(hour=0)).total_seconds() / 3600)
            self.assertEqual(c["risk_label"], "Severe" if hour >= 8 else "Low", (c["mile"], c["eta"]))


if __name__ == "__main__":
    unittest.main()
