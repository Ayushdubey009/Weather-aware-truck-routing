import unittest

from planner import geo
from planner.osrm import build_profile
from planner.analysis import plan_checkpoints


class GeoTests(unittest.TestCase):
    def setUp(self):
        self.coords = [(0.0, 0.0), (0.0, 1.0), (0.0, 2.0)]
        self.cum = geo.cumulative_haversine(self.coords)

    def test_haversine_one_degree_at_equator(self):
        self.assertAlmostEqual(geo.haversine_m((0, 0), (0, 1)), 111_195, delta=200)

    def test_interpolate_midpoint(self):
        lat, lon = geo.interpolate_at(self.coords, self.cum, self.cum[-1] / 2)
        self.assertAlmostEqual(lat, 0.0, places=6)
        self.assertAlmostEqual(lon, 1.0, places=3)

    def test_interpolate_clamps(self):
        self.assertEqual(geo.interpolate_at(self.coords, self.cum, -5), self.coords[0])
        self.assertEqual(geo.interpolate_at(self.coords, self.cum, 1e12), self.coords[-1])

    def test_slice_path_includes_interior_vertices(self):
        total = self.cum[-1]
        path = geo.slice_path(self.coords, self.cum, total * 0.25, total * 0.75)
        self.assertEqual(len(path), 3)  # start, vertex at lon=1, end
        self.assertAlmostEqual(path[0][1], 0.5, places=3)
        self.assertAlmostEqual(path[1][1], 1.0, places=6)
        self.assertAlmostEqual(path[2][1], 1.5, places=3)

    def test_decimate_keeps_ends(self):
        pts = [(0, i * 0.0001) for i in range(100)]
        out = geo.decimate(pts, 500)
        self.assertEqual(out[0], pts[0])
        self.assertEqual(out[-1], pts[-1])
        self.assertLess(len(out), len(pts))

    def test_destination_point_roundtrip(self):
        a = (40.0, -100.0)
        b = geo.destination_point(a, 90, 50_000)
        self.assertAlmostEqual(geo.haversine_m(a, b), 50_000, delta=5)

    def test_overlap_fraction(self):
        a = [(0, i * 0.01) for i in range(50)]
        far = [(1.0, i * 0.01) for i in range(50)]
        self.assertAlmostEqual(geo.overlap_fraction(a, a), 1.0)
        self.assertAlmostEqual(geo.overlap_fraction(a, far), 0.0)

    def test_interp_value(self):
        self.assertEqual(geo.interp_value([0, 10], [0, 100], 5), 50)
        self.assertEqual(geo.interp_value([0, 10], [0, 100], 99), 100)


class ProfileTests(unittest.TestCase):
    def test_uses_annotations_and_normalises_to_totals(self):
        coords = [(0, 0), (0, 1), (0, 2)]
        cum_m, cum_s = build_profile(coords, [100, 300], [10, 30], total_m=800, total_s=120)
        self.assertEqual(cum_m, [0, 200, 800])
        self.assertEqual(cum_s, [0, 30, 120])

    def test_falls_back_when_annotations_mismatch(self):
        coords = [(0, 0), (0, 1), (0, 2)]
        cum_m, cum_s = build_profile(coords, [1], [1], total_m=1000, total_s=100)
        self.assertAlmostEqual(cum_m[-1], 1000)
        self.assertAlmostEqual(cum_s[1], 50, delta=0.5)  # constant speed


class CheckpointPlanTests(unittest.TestCase):
    def test_regular_spacing_and_destination(self):
        miles, eff = plan_checkpoints(120, 25, 150)
        self.assertEqual(eff, 25)
        self.assertEqual(miles, [0, 25, 50, 75, 100, 120])

    def test_no_sliver_before_destination(self):
        miles, _ = plan_checkpoints(101, 25, 150)
        self.assertEqual(miles, [0, 25, 50, 75, 101])

    def test_short_route(self):
        self.assertEqual(plan_checkpoints(8, 25, 150)[0], [0, 8])

    def test_interval_widens_to_cap_points(self):
        miles, eff = plan_checkpoints(3000, 10, 150)
        self.assertGreater(eff, 10)
        self.assertLessEqual(len(miles), 151)


if __name__ == "__main__":
    unittest.main()
