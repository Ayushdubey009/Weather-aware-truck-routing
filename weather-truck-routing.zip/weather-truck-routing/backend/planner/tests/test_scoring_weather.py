import unittest
from datetime import datetime, timezone, timedelta

from planner import scoring
from planner.risk import Risk
from planner.weather import HourlySeries, parse_location, point_key


def route(name, *, nt=0, sev=0, high=0, avg=0.0, minutes=100):
    return {"name": name, "duration_minutes": minutes,
            "summary": {"no_travel_miles": nt, "severe_miles": sev, "high_miles": high, "avg_risk": avg}}


class ScoringTests(unittest.TestCase):
    def test_segment_bounds_cover_route_exactly(self):
        b = scoring.segment_bounds([0, 25, 50, 60], 60)
        self.assertEqual(b, [(0, 12.5), (12.5, 37.5), (37.5, 55), (55, 60)])
        self.assertEqual(sum(e - s for s, e in b), 60)

    def test_summarize_miles_and_average(self):
        levels = [Risk.LOW, Risk.SEVERE, Risk.HIGH]
        s = scoring.summarize(levels, [(0, 50), (50, 60), (60, 100)])
        self.assertEqual(s["severe_miles"], 10)
        self.assertEqual(s["high_miles"], 40)
        self.assertEqual(s["miles_by_level"]["low"], 50)
        self.assertAlmostEqual(s["avg_risk"], (0 * 50 + 3 * 10 + 2 * 40) / 100)
        self.assertEqual(s["worst_label"], "Severe")

    def test_ranking_priority_order(self):
        fast_severe = route("A", sev=20, minutes=60)
        slow_clean = route("B", sev=0, high=30, minutes=300)
        mid = route("C", sev=0, high=10, minutes=200)
        order = [r["name"] for r in scoring.rank_routes([fast_severe, slow_clean, mid])]
        self.assertEqual(order, ["C", "B", "A"])  # fewer Severe beats speed; then fewer High

    def test_no_travel_routes_lose_to_everything(self):
        blocked = route("A", nt=5, minutes=10)
        bad = route("B", sev=100, minutes=500)
        self.assertEqual(scoring.rank_routes([blocked, bad])[0]["name"], "B")

    def test_tiebreaks_avg_risk_then_time(self):
        a = route("A", avg=0.50, minutes=90)
        b = route("B", avg=0.40, minutes=120)
        c = route("C", avg=0.40, minutes=100)
        self.assertEqual([r["name"] for r in scoring.rank_routes([a, b, c])], ["C", "B", "A"])

    def test_rounding_absorbs_noise(self):
        a = route("A", sev=10.2, minutes=100)
        b = route("B", sev=9.8, minutes=90)  # both 10 mi once rounded -> faster wins
        self.assertEqual(scoring.rank_routes([a, b])[0]["name"], "B")

    def test_explanations(self):
        ranked = scoring.rank_routes([route("A", sev=20), route("B", sev=0, high=5), route("C", sev=0, high=5, minutes=130)])
        text = " ".join(scoring.explain(ranked))
        self.assertIn("20 more Severe miles", text)
        self.assertIn("30 min slower", text)


class WeatherParsingTests(unittest.TestCase):
    PAYLOAD = {"hourly": {"time": ["2026-11-01T00:00", "2026-11-01T01:00", "2026-11-01T02:00"],
                          "wind_speed_10m": [10, None, 40],
                          "rain": [0.0, 0.1, None], "showers": [0.0, 0.05, 0.2],
                          "snowfall": [0.0, None, 1.5]}}

    def test_parse_location_sums_rain_and_fills_none(self):
        s = parse_location(self.PAYLOAD)
        self.assertEqual(s.start, datetime(2026, 11, 1, tzinfo=timezone.utc))
        self.assertEqual(s.wind_mph, (10.0, 0.0, 40.0))
        self.assertAlmostEqual(s.rain_in_hr[1], 0.15)
        self.assertAlmostEqual(s.rain_in_hr[2], 0.2)
        self.assertEqual(s.snow_in_hr, (0.0, 0.0, 1.5))

    def test_sampling_rounds_to_nearest_hour_and_clamps(self):
        s = parse_location(self.PAYLOAD)
        t0 = s.start
        self.assertEqual(s.at(t0 + timedelta(minutes=100)).wind_mph, 40.0)  # 1h40 -> hour 2
        self.assertEqual(s.at(t0 + timedelta(minutes=20)).wind_mph, 10.0)
        self.assertEqual(s.at(t0 + timedelta(days=5)).wind_mph, 40.0)  # clamped
        self.assertEqual(s.at(t0 - timedelta(days=1)).wind_mph, 10.0)

    def test_point_key_grid(self):
        self.assertEqual(point_key(41.8781, -87.6298), (41.88, -87.63))


if __name__ == "__main__":
    unittest.main()
