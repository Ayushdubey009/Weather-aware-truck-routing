import unittest

from planner.risk import Risk, assess, classify, WIND, RAIN, SNOW


class ClassifyTests(unittest.TestCase):
    def test_wind_bands(self):
        cases = [(0, Risk.LOW), (24.9, Risk.LOW), (25, Risk.MODERATE), (34.9, Risk.MODERATE),
                 (35, Risk.HIGH), (44.9, Risk.HIGH), (45, Risk.SEVERE), (54.9, Risk.SEVERE),
                 (55, Risk.NO_TRAVEL), (80, Risk.NO_TRAVEL)]
        for v, expected in cases:
            self.assertEqual(classify(v, WIND), expected, v)

    def test_rain_bands(self):
        cases = [(0.099, Risk.LOW), (0.10, Risk.MODERATE), (0.25, Risk.HIGH), (0.50, Risk.SEVERE),
                 (1.00, Risk.SEVERE), (1.01, Risk.NO_TRAVEL)]
        for v, expected in cases:
            self.assertEqual(classify(v, RAIN), expected, v)

    def test_snow_bands(self):
        cases = [(0.4, Risk.LOW), (0.5, Risk.MODERATE), (1.0, Risk.HIGH), (2.0, Risk.SEVERE),
                 (3.0, Risk.SEVERE), (3.1, Risk.NO_TRAVEL)]
        for v, expected in cases:
            self.assertEqual(classify(v, SNOW), expected, v)


class LoadRuleTests(unittest.TestCase):
    def test_55mph_is_no_travel_for_any_load(self):
        self.assertEqual(assess(55, 0, 0, 0).level, Risk.NO_TRAVEL)
        self.assertEqual(assess(60, 0, 0, 5_000).level, Risk.NO_TRAVEL)

    def test_45_to_54_heavy_load_is_no_travel(self):
        self.assertEqual(assess(50, 0, 0, 30_001).level, Risk.NO_TRAVEL)
        self.assertEqual(assess(50, 0, 0, 30_000).level, Risk.SEVERE)  # not strictly > 30,000
        self.assertEqual(assess(50, 0, 0, 10_000).level, Risk.SEVERE)

    def test_35_to_44_very_heavy_load_is_severe(self):
        self.assertEqual(assess(40, 0, 0, 40_001).level, Risk.SEVERE)
        self.assertEqual(assess(40, 0, 0, 40_000).level, Risk.HIGH)
        self.assertEqual(assess(40, 0, 0, 20_000).level, Risk.HIGH)

    def test_load_rules_never_lower_risk(self):
        # heavy snow already Severe; a heavy load with moderate wind must not downgrade it
        self.assertEqual(assess(36, 0, 2.5, 45_000).level, Risk.SEVERE)
        self.assertEqual(assess(10, 1.5, 0, 80_000).level, Risk.NO_TRAVEL)

    def test_overall_is_worst_condition(self):
        a = assess(26, 0.3, 0.6, 10_000)
        self.assertEqual((a.wind, a.rain, a.snow), (Risk.MODERATE, Risk.HIGH, Risk.MODERATE))
        self.assertEqual(a.level, Risk.HIGH)
        self.assertEqual(len(a.drivers), 3)

    def test_calm_weather_is_low(self):
        a = assess(5, 0, 0, 80_000)
        self.assertEqual(a.level, Risk.LOW)
        self.assertEqual(a.drivers, ())


if __name__ == "__main__":
    unittest.main()
