"""Hourly weather from Open-Meteo (free, no API key, forecasts up to 16 days).

Units are requested in mph and inches so values compare directly with the
brief's thresholds. Snow is `snowfall` (inches of snow per hour), rain is
`rain + showers` (inches of liquid per hour).
"""
from __future__ import annotations

import logging
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import date, datetime, timezone

import requests

from .errors import UpstreamError

log = logging.getLogger(__name__)

CHUNK_SIZE = 40  # locations per HTTP request
HOURLY_VARS = "wind_speed_10m,rain,showers,snowfall"

Key = tuple[float, float]


@dataclass(frozen=True)
class Reading:
    wind_mph: float
    rain_in_hr: float
    snow_in_hr: float


@dataclass(frozen=True)
class HourlySeries:
    start: datetime  # UTC time of index 0
    wind_mph: tuple[float, ...]
    rain_in_hr: tuple[float, ...]
    snow_in_hr: tuple[float, ...]

    def index_at(self, when: datetime) -> int:
        i = round((when - self.start).total_seconds() / 3600)
        return max(0, min(len(self.wind_mph) - 1, i))

    def at_index(self, i: int) -> Reading:
        i = max(0, min(len(self.wind_mph) - 1, i))
        return Reading(self.wind_mph[i], self.rain_in_hr[i], self.snow_in_hr[i])

    def at(self, when: datetime) -> Reading:
        return self.at_index(self.index_at(when))


def point_key(lat: float, lon: float) -> Key:
    """~1 km grid; Open-Meteo's own grid is coarser, so nothing is lost."""
    return (round(lat, 2), round(lon, 2))


def parse_location(payload: dict) -> HourlySeries:
    h = payload["hourly"]
    start = datetime.fromisoformat(h["time"][0]).replace(tzinfo=timezone.utc)
    z = lambda v: float(v) if v is not None else 0.0  # noqa: E731
    wind = tuple(z(v) for v in h["wind_speed_10m"])
    rain = tuple(z(a) + z(b) for a, b in zip(h["rain"], h["showers"]))
    snow = tuple(z(v) for v in h["snowfall"])
    return HourlySeries(start, wind, rain, snow)


def _fetch_chunk(keys: list[Key], start: date, end: date) -> dict[Key, HourlySeries]:
    from django.conf import settings

    params = {
        "latitude": ",".join(f"{k[0]:.2f}" for k in keys),
        "longitude": ",".join(f"{k[1]:.2f}" for k in keys),
        "hourly": HOURLY_VARS,
        "wind_speed_unit": "mph",
        "precipitation_unit": "inch",
        "timezone": "GMT",
        "start_date": start.isoformat(),
        "end_date": end.isoformat(),
    }
    last_err = "unknown error"
    for attempt in range(3):
        try:
            resp = requests.get(
                settings.OPEN_METEO_URL,
                params=params,
                headers={"User-Agent": settings.HTTP_USER_AGENT},
                timeout=30,
            )
            if resp.status_code == 429 or resp.status_code >= 500:
                last_err = f"HTTP {resp.status_code}"
                time.sleep(1.5 * (attempt + 1))
                continue
            data = resp.json()
            if resp.status_code != 200:
                raise UpstreamError(f"Weather service error: {data.get('reason', resp.status_code)}")
            locations = data if isinstance(data, list) else [data]
            return {k: parse_location(loc) for k, loc in zip(keys, locations)}
        except (requests.RequestException, ValueError) as exc:
            last_err = str(exc)
            time.sleep(1.0)
    raise UpstreamError(f"Weather service unavailable ({last_err}).")


def fetch_weather(points: list[tuple[float, float]], start: date, end: date) -> dict[Key, HourlySeries]:
    """Hourly series for every point, batched, parallel and cached for a few minutes."""
    from django.conf import settings
    from django.core.cache import cache

    keys = list(dict.fromkeys(point_key(*p) for p in points))
    cache_key = lambda k: f"wx:{k[0]:.2f}:{k[1]:.2f}:{start}:{end}"  # noqa: E731
    found = cache.get_many([cache_key(k) for k in keys])
    result: dict[Key, HourlySeries] = {k: found[cache_key(k)] for k in keys if cache_key(k) in found}

    missing = [k for k in keys if k not in result]
    chunks = [missing[i : i + CHUNK_SIZE] for i in range(0, len(missing), CHUNK_SIZE)]
    if chunks:
        with ThreadPoolExecutor(max_workers=min(4, len(chunks))) as pool:
            for part in pool.map(lambda c: _fetch_chunk(c, start, end), chunks):
                result.update(part)
                cache.set_many({cache_key(k): v for k, v in part.items()}, settings.WEATHER_CACHE_TTL)
    return result
