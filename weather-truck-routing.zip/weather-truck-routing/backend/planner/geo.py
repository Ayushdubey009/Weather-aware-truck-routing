"""Small, dependency-free geodesy helpers."""
from __future__ import annotations

import bisect
import math
from typing import Sequence

EARTH_RADIUS_M = 6_371_008.8
METERS_PER_MILE = 1609.344

LatLon = tuple[float, float]


def haversine_m(a: LatLon, b: LatLon) -> float:
    lat1, lon1 = math.radians(a[0]), math.radians(a[1])
    lat2, lon2 = math.radians(b[0]), math.radians(b[1])
    h = (
        math.sin((lat2 - lat1) / 2) ** 2
        + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    )
    return 2 * EARTH_RADIUS_M * math.asin(min(1.0, math.sqrt(h)))


def cumulative_haversine(coords: Sequence[LatLon]) -> list[float]:
    cum = [0.0]
    for i in range(1, len(coords)):
        cum.append(cum[-1] + haversine_m(coords[i - 1], coords[i]))
    return cum


def interpolate_at(coords: Sequence[LatLon], cum: Sequence[float], target: float) -> LatLon:
    """Point located `target` metres along a path whose cumulative distances are `cum`."""
    if target <= 0:
        return coords[0]
    if target >= cum[-1]:
        return coords[-1]
    i = bisect.bisect_right(cum, target)
    seg = cum[i] - cum[i - 1]
    t = 0.0 if seg <= 0 else (target - cum[i - 1]) / seg
    (la1, lo1), (la2, lo2) = coords[i - 1], coords[i]
    return (la1 + (la2 - la1) * t, lo1 + (lo2 - lo1) * t)


def interp_value(xs: Sequence[float], ys: Sequence[float], x: float) -> float:
    """Linear interpolation of y(x) over monotonically increasing xs."""
    if x <= xs[0]:
        return ys[0]
    if x >= xs[-1]:
        return ys[-1]
    i = bisect.bisect_right(xs, x)
    span = xs[i] - xs[i - 1]
    t = 0.0 if span <= 0 else (x - xs[i - 1]) / span
    return ys[i - 1] + (ys[i] - ys[i - 1]) * t


def slice_path(
    coords: Sequence[LatLon], cum: Sequence[float], start: float, end: float
) -> list[LatLon]:
    """Sub-path between two distances along the path (both ends interpolated)."""
    start = max(0.0, min(start, cum[-1]))
    end = max(start, min(end, cum[-1]))
    lo = bisect.bisect_right(cum, start)
    hi = bisect.bisect_left(cum, end)
    return [interpolate_at(coords, cum, start), *coords[lo:hi], interpolate_at(coords, cum, end)]


def decimate(coords: Sequence[LatLon], min_step_m: float) -> list[LatLon]:
    """Drop points closer than `min_step_m` to the previously kept one (keeps first & last)."""
    if len(coords) <= 2:
        return list(coords)
    kept = [coords[0]]
    for p in coords[1:-1]:
        if haversine_m(kept[-1], p) >= min_step_m:
            kept.append(p)
    kept.append(coords[-1])
    return kept


def bearing_deg(a: LatLon, b: LatLon) -> float:
    lat1, lat2 = math.radians(a[0]), math.radians(b[0])
    dlon = math.radians(b[1] - a[1])
    y = math.sin(dlon) * math.cos(lat2)
    x = math.cos(lat1) * math.sin(lat2) - math.sin(lat1) * math.cos(lat2) * math.cos(dlon)
    return (math.degrees(math.atan2(y, x)) + 360) % 360


def destination_point(a: LatLon, bearing: float, dist_m: float) -> LatLon:
    lat1, lon1 = math.radians(a[0]), math.radians(a[1])
    brg = math.radians(bearing)
    d = dist_m / EARTH_RADIUS_M
    lat2 = math.asin(math.sin(lat1) * math.cos(d) + math.cos(lat1) * math.sin(d) * math.cos(brg))
    lon2 = lon1 + math.atan2(
        math.sin(brg) * math.sin(d) * math.cos(lat1),
        math.cos(d) - math.sin(lat1) * math.sin(lat2),
    )
    return (math.degrees(lat2), (math.degrees(lon2) + 540) % 360 - 180)


def overlap_fraction(
    a: Sequence[LatLon], b: Sequence[LatLon], radius_m: float = 2500.0, cell_deg: float = 0.05
) -> float:
    """Share of points in `a` that lie within `radius_m` of some point in `b` (grid-hashed)."""
    if not a or not b:
        return 0.0
    grid: dict[tuple[int, int], list[LatLon]] = {}
    for q in b:
        grid.setdefault((int(q[0] // cell_deg), int(q[1] // cell_deg)), []).append(q)
    near = 0
    for p in a:
        ci, cj = int(p[0] // cell_deg), int(p[1] // cell_deg)
        found = any(
            haversine_m(p, q) <= radius_m
            for di in (-1, 0, 1)
            for dj in (-1, 0, 1)
            for q in grid.get((ci + di, cj + dj), ())
        )
        near += found
    return near / len(a)
