"""Weather risk classification - the thresholds and load rules from the brief.

Band edges (lower bound of each level is inclusive):

    Condition   Moderate  High   Severe  No Travel
    Wind mph    >=25      >=35   >=45    >=55
    Rain in/hr  >=0.10    >=0.25 >=0.50  > 1.00
    Snow in/hr  >=0.5     >=1.0  >=2.0   > 3.0

The brief's table repeats its boundary values in two columns (e.g. "0.10-0.25"
and "0.25-0.50"), so we resolve ties toward the *more* severe band. The "No
Travel" column is written ">=55" for wind but ">1.00" / ">3.0" for rain/snow,
and we honour that exactly.

Load rules (heavier loads are less stable in wind):
    * wind >= 55 mph                      -> No Travel, any load
    * wind 45-54 mph and load > 30,000 lb -> No Travel
    * wind 35-44 mph and load > 40,000 lb -> Severe
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum


class Risk(IntEnum):
    LOW = 0
    MODERATE = 1
    HIGH = 2
    SEVERE = 3
    NO_TRAVEL = 4

    @property
    def label(self) -> str:
        return {0: "Low", 1: "Moderate", 2: "High", 3: "Severe", 4: "No Travel"}[self.value]


@dataclass(frozen=True)
class Thresholds:
    moderate: float
    high: float
    severe: float
    no_travel: float
    no_travel_inclusive: bool = False


WIND = Thresholds(25, 35, 45, 55, no_travel_inclusive=True)
RAIN = Thresholds(0.10, 0.25, 0.50, 1.00)
SNOW = Thresholds(0.5, 1.0, 2.0, 3.0)

LOAD_NO_TRAVEL_WIND_FLOOR = 45.0
LOAD_NO_TRAVEL_THRESHOLD_LB = 30_000
LOAD_SEVERE_WIND_FLOOR = 35.0
LOAD_SEVERE_THRESHOLD_LB = 40_000


def classify(value: float, t: Thresholds) -> Risk:
    v = round(float(value), 3)  # absorb float noise from unit conversion
    if (v >= t.no_travel) if t.no_travel_inclusive else (v > t.no_travel):
        return Risk.NO_TRAVEL
    if v >= t.severe:
        return Risk.SEVERE
    if v >= t.high:
        return Risk.HIGH
    if v >= t.moderate:
        return Risk.MODERATE
    return Risk.LOW


@dataclass(frozen=True)
class Assessment:
    level: Risk
    wind: Risk
    rain: Risk
    snow: Risk
    drivers: tuple[str, ...] = field(default_factory=tuple)


def assess(wind_mph: float, rain_in_hr: float, snow_in_hr: float, load_lb: float) -> Assessment:
    """Overall risk at one checkpoint = worst condition, then escalated by load rules."""
    wind_r = classify(wind_mph, WIND)
    rain_r = classify(rain_in_hr, RAIN)
    snow_r = classify(snow_in_hr, SNOW)
    level = max(wind_r, rain_r, snow_r)

    drivers: list[str] = []
    if wind_r >= Risk.MODERATE:
        drivers.append(f"Wind {wind_mph:.0f} mph ({wind_r.label})")
    if rain_r >= Risk.MODERATE:
        drivers.append(f"Rain {rain_in_hr:.2f} in/hr ({rain_r.label})")
    if snow_r >= Risk.MODERATE:
        drivers.append(f"Snow {snow_in_hr:.1f} in/hr ({snow_r.label})")

    wind = round(float(wind_mph), 3)
    if wind >= WIND.no_travel:
        level = Risk.NO_TRAVEL  # already implied by classify(); explicit for clarity
    elif wind >= LOAD_NO_TRAVEL_WIND_FLOOR and load_lb > LOAD_NO_TRAVEL_THRESHOLD_LB:
        level = Risk.NO_TRAVEL
        drivers.append(f"Load rule: {load_lb:,.0f} lb in {wind_mph:.0f} mph wind (No Travel)")
    elif wind >= LOAD_SEVERE_WIND_FLOOR and load_lb > LOAD_SEVERE_THRESHOLD_LB:
        if level < Risk.SEVERE:
            level = Risk.SEVERE
        drivers.append(f"Load rule: {load_lb:,.0f} lb in {wind_mph:.0f} mph wind (Severe)")

    return Assessment(level, wind_r, rain_r, snow_r, tuple(drivers))
