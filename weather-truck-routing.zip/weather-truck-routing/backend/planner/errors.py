"""Exceptions that map cleanly to JSON error responses."""


class ApiError(Exception):
    status = 400
    code = "bad_request"

    def __init__(self, message: str, status: int | None = None, code: str | None = None):
        super().__init__(message)
        self.message = message
        if status is not None:
            self.status = status
        if code is not None:
            self.code = code


class UpstreamError(ApiError):
    """A third-party service (routing, geocoding, weather) failed."""

    status = 502
    code = "upstream_error"
