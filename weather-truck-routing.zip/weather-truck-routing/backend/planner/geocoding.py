"""Place search via OpenStreetMap Nominatim (no API key)."""
from __future__ import annotations

import re

import requests

from .errors import ApiError, UpstreamError

_LATLON = re.compile(r"^\s*(-?\d{1,2}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)\s*$")


def search(query: str, limit: int = 5) -> list[dict]:
    from django.conf import settings
    from django.core.cache import cache

    query = " ".join(query.split())
    if len(query) < 2:
        return []
    ck = f"geo:{limit}:{query.lower()}"
    cached = cache.get(ck)
    if cached is not None:
        return cached
    params = {"q": query, "format": "jsonv2", "limit": limit}
    if settings.GEOCODER_COUNTRY_CODES:
        params["countrycodes"] = settings.GEOCODER_COUNTRY_CODES
    try:
        resp = requests.get(
            settings.NOMINATIM_URL,
            params=params,
            headers={"User-Agent": settings.HTTP_USER_AGENT},
            timeout=15,
        )
        resp.raise_for_status()
        rows = resp.json()
    except (requests.RequestException, ValueError) as exc:
        raise UpstreamError(f"Geocoding service unavailable: {exc}") from exc
    results = [
        {"label": r["display_name"], "lat": float(r["lat"]), "lon": float(r["lon"])} for r in rows
    ]
    cache.set(ck, results, 24 * 3600)
    return results


def resolve_place(spec: dict, field: str) -> dict:
    """Accepts {lat, lon[, label]} or {query}; returns {label, lat, lon}."""
    if spec.get("lat") is not None and spec.get("lon") is not None:
        lat, lon = float(spec["lat"]), float(spec["lon"])
        return {"label": spec.get("label") or f"{lat:.4f}, {lon:.4f}", "lat": lat, "lon": lon}
    query = (spec.get("query") or "").strip()
    m = _LATLON.match(query)
    if m:
        lat, lon = float(m.group(1)), float(m.group(2))
        return {"label": f"{lat:.4f}, {lon:.4f}", "lat": lat, "lon": lon}
    hits = search(query, limit=1)
    if not hits:
        raise ApiError(f"Couldn't find a place matching '{query}' for the {field}.", 422, "place_not_found")
    return hits[0]
