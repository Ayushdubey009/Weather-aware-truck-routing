"""Orchestrates one trip analysis: routes -> checkpoints -> weather -> risk -> ranking."""
from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Callable

from . import geo, geocoding, osrm, scoring, weather
from .errors import ApiError
from .risk import Risk, assess
from .validation import AnalyzeRequest

FORECAST_HOURS = 48
SEGMENT_SIMPLIFY_M = 400.0


@dataclass
class Providers:
    """Injected so the pipeline can be tested without network access."""

    resolve_place: Callable = geocoding.resolve_place
    get_routes: Callable = osrm.get_routes
    fetch_weather: Callable = weather.fetch_weather


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def plan_checkpoints(total_miles: float, interval: int, max_points: int) -> tuple[list[float], int]:
    """Mile markers 0, I, 2I ... plus the destination. Widens I if the route would exceed max_points."""
    effective = max(interval, math.ceil(total_miles / max(1, max_points - 1)))
    miles = [0.0]
    m = float(effective)
    while m < total_miles - effective * 0.25:  # don't leave a sliver before the destination
        miles.append(m)
        m += effective
    if total_miles > 0.01:
        miles.append(total_miles)
    return miles, effective


def _round_path(path):
    return [[round(lat, 5), round(lon, 5)] for lat, lon in path]


def _segments(route: osrm.RawRoute, levels, bounds) -> list[dict]:
    """Route geometry split into runs of constant risk level (for colouring the line)."""
    runs: list[dict] = []
    for level, (start, end) in zip(levels, bounds):
        path = geo.slice_path(route.coords, route.cum_m, start * geo.METERS_PER_MILE, end * geo.METERS_PER_MILE)
        if runs and runs[-1]["level"] == int(level):
            runs[-1]["path"].extend(path[1:])
            runs[-1]["to_mile"] = round(end, 1)
        else:
            runs.append({"level": int(level), "from_mile": round(start, 1), "to_mile": round(end, 1), "path": path})
    for run in runs:
        run["path"] = _round_path(geo.decimate(run["path"], SEGMENT_SIMPLIFY_M))
    return runs


def analyze_trip(req: AnalyzeRequest, providers: Providers | None = None) -> dict:
    from django.conf import settings

    p = providers or Providers()
    origin = p.resolve_place(req.origin, "origin")
    dest = p.resolve_place(req.destination, "destination")
    o_pt, d_pt = (origin["lat"], origin["lon"]), (dest["lat"], dest["lon"])
    if geo.haversine_m(o_pt, d_pt) < 500:
        raise ApiError("Origin and destination are the same place.", 422, "same_place")

    raw_routes = p.get_routes(o_pt, d_pt, settings.TRUCK_DURATION_FACTOR)

    # 1. Checkpoints with positions + ETAs for every route
    plans = []
    for route in raw_routes:
        miles, effective = plan_checkpoints(
            route.distance_m / geo.METERS_PER_MILE, req.interval_miles, settings.MAX_CHECKPOINTS_PER_ROUTE
        )
        pts = []
        for mile in miles:
            d = mile * geo.METERS_PER_MILE
            lat, lon = geo.interpolate_at(route.coords, route.cum_m, d)
            eta = req.departure + timedelta(seconds=geo.interp_value(route.cum_m, route.cum_s, d))
            pts.append({"mile": mile, "lat": lat, "lon": lon, "eta": eta})
        plans.append((route, pts, effective))

    # 2. One batched weather fetch covering every ETA and the 48h heatmap window
    forecast_start = req.departure.replace(minute=0, second=0, microsecond=0)
    if req.departure.minute >= 30:
        forecast_start += timedelta(hours=1)
    last_eta = max(pt["eta"] for _, pts, _ in plans for pt in pts)
    window_end = max(last_eta, forecast_start + timedelta(hours=FORECAST_HOURS))
    series_by_key = p.fetch_weather(
        [(pt["lat"], pt["lon"]) for _, pts, _ in plans for pt in pts],
        forecast_start.date(),
        window_end.date(),
    )

    # 3. Assess risk, summarise, build response objects
    routes_out = []
    for idx, (route, pts, effective) in enumerate(plans):
        checkpoints, levels = [], []
        for n, pt in enumerate(pts):
            series = series_by_key[weather.point_key(pt["lat"], pt["lon"])]
            reading = series.at(pt["eta"])
            a = assess(reading.wind_mph, reading.rain_in_hr, reading.snow_in_hr, req.load_lb)

            base = series.index_at(forecast_start)
            fc = {"levels": [], "wind": [], "rain": [], "snow": []}
            for h in range(FORECAST_HOURS + 1):
                r = series.at_index(base + h)
                fc["levels"].append(int(assess(r.wind_mph, r.rain_in_hr, r.snow_in_hr, req.load_lb).level))
                fc["wind"].append(round(r.wind_mph, 1))
                fc["rain"].append(round(r.rain_in_hr, 3))
                fc["snow"].append(round(r.snow_in_hr, 3))

            levels.append(a.level)
            checkpoints.append(
                {
                    "index": n,
                    "mile": round(pt["mile"], 1),
                    "lat": round(pt["lat"], 5),
                    "lon": round(pt["lon"], 5),
                    "eta": iso(pt["eta"]),
                    "wind_mph": round(reading.wind_mph, 1),
                    "rain_in_hr": round(reading.rain_in_hr, 3),
                    "snow_in_hr": round(reading.snow_in_hr, 3),
                    "risk_level": int(a.level),
                    "risk_label": a.level.label,
                    "drivers": list(a.drivers),
                    "forecast": fc,
                }
            )

        total_miles = route.distance_m / geo.METERS_PER_MILE
        bounds = scoring.segment_bounds([c["mile"] for c in checkpoints], total_miles)
        routes_out.append(
            {
                "id": f"route-{idx + 1}",
                "name": f"Route {chr(65 + idx)}",
                "distance_miles": round(total_miles, 1),
                "duration_minutes": round(route.duration_s / 60),
                "arrival": iso(req.departure + timedelta(seconds=route.duration_s)),
                "checkpoint_interval_miles": effective,
                "summary": scoring.summarize(levels, bounds),
                "segments": _segments(route, levels, bounds),
                "checkpoints": checkpoints,
            }
        )

    ranked = scoring.rank_routes(routes_out)
    reasons = scoring.explain(ranked)
    for rank, r in enumerate(ranked, start=1):
        r["rank"] = rank
        r["recommended"] = rank == 1

    return {
        "origin": origin,
        "destination": dest,
        "departure": iso(req.departure),
        "forecast_start": iso(forecast_start),
        "forecast_hours": FORECAST_HOURS,
        "load_weight_lb": req.load_lb,
        "interval_miles": max(r["checkpoint_interval_miles"] for r in routes_out),
        "routes": routes_out,  # original order (fastest first); `rank` gives the recommendation order
        "recommendation": {"route_id": ranked[0]["id"], "reasons": reasons},
    }
