import json
import logging

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_POST

from . import analysis, geocoding
from .errors import ApiError
from .validation import parse_analyze_request

log = logging.getLogger(__name__)


def _error(exc: ApiError) -> JsonResponse:
    return JsonResponse({"error": {"code": exc.code, "message": exc.message}}, status=exc.status)


@require_GET
def health(request):
    return JsonResponse({"status": "ok"})


@require_GET
def geocode(request):
    try:
        return JsonResponse({"results": geocoding.search(request.GET.get("q", ""))})
    except ApiError as exc:
        return _error(exc)


@csrf_exempt
@require_POST
def analyze(request):
    try:
        try:
            body = json.loads(request.body or b"{}")
        except ValueError:
            raise ApiError("Request body is not valid JSON.") from None
        req = parse_analyze_request(body)
        return JsonResponse(analysis.analyze_trip(req))
    except ApiError as exc:
        return _error(exc)
    except Exception:  # noqa: BLE001 - last-resort guard so the client always gets JSON
        log.exception("Unhandled error while analysing trip")
        return JsonResponse(
            {"error": {"code": "internal_error", "message": "Something went wrong planning that trip."}},
            status=500,
        )
