"""Routing via an OSRM server (the public demo server by default; no API key).

OSRM returns up to 3 alternatives for many city pairs but often fewer. The brief
asks for three options, so when OSRM returns fewer we synthesise extra candidates
by routing through a via-point pushed sideways from the middle of the fastest
route, and keep only candidates that are genuinely different roads.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

import requests

from . import geo
from .errors import ApiError, UpstreamError

log = logging.getLogger(__name__)

WANTED_ROUTES = 3
MAX_DETOUR_RATIO = 1.75  # reject candidates much longer than the fastest route
MAX_OVERLAP = 0.85  # reject candidates that share >85% of their path with another route


@dataclass
class RawRoute:
    coords: list[geo.LatLon]
    cum_m: list[float]  # cumulative distance (m) at every coordinate
    cum_s: list[float]  # cumulative driving time (s) at every coordinate
    distance_m: float
    duration_s: float


def _scale(cum: list[float], total: float) -> list[float]:
    last = cum[-1]
    if last <= 0:
        return cum
    k = total / last
    return [v * k for v in cum]


def build_profile(coords, dist_ann, dur_ann, total_m, total_s):
    """Cumulative distance/time per coordinate, normalised to OSRM's route totals.

    OSRM's per-segment `annotation` arrays line up with the full-resolution
    geometry. If they ever don't (e.g. simplified geometry), fall back to
    haversine distances and constant speed so ETAs stay sensible.
    """
    n = len(coords)
    if dist_ann and len(dist_ann) == n - 1:
        cum_m = [0.0]
        for d in dist_ann:
            cum_m.append(cum_m[-1] + d)
    else:
        cum_m = geo.cumulative_haversine(coords)
    if dur_ann and len(dur_ann) == n - 1:
        cum_s = [0.0]
        for d in dur_ann:
            cum_s.append(cum_s[-1] + d)
    else:
        cum_s = list(cum_m)
    return _scale(cum_m, total_m), _scale(cum_s, total_s)


def _parse_route(route: dict, duration_factor: float) -> RawRoute:
    coords = [(lat, lon) for lon, lat in route["geometry"]["coordinates"]]
    dist_ann: list[float] = []
    dur_ann: list[float] = []
    for leg in route.get("legs", []):
        ann = leg.get("annotation") or {}
        dist_ann += ann.get("distance", [])
        dur_ann += ann.get("duration", [])
    total_m = float(route["distance"])
    total_s = float(route["duration"]) * duration_factor
    cum_m, cum_s = build_profile(coords, dist_ann, dur_ann, total_m, total_s)
    return RawRoute(coords, cum_m, cum_s, total_m, total_s)


def fetch_routes(points: list[geo.LatLon], alternatives: bool, duration_factor: float) -> list[RawRoute]:
    from django.conf import settings

    path = ";".join(f"{lon:.6f},{lat:.6f}" for lat, lon in points)
    url = f"{settings.OSRM_BASE_URL.rstrip('/')}/route/v1/driving/{path}"
    params = {
        "alternatives": "3" if alternatives else "false",
        "overview": "full",
        "geometries": "geojson",
        "annotations": "distance,duration",
        "steps": "false",
    }
    try:
        resp = requests.get(url, params=params, headers={"User-Agent": settings.HTTP_USER_AGENT}, timeout=40)
    except requests.RequestException as exc:
        raise UpstreamError(f"Routing service unreachable: {exc}") from exc
    try:
        data = resp.json()
    except ValueError:
        data = {}
    code = data.get("code")
    if code == "NoRoute":
        raise ApiError("No drivable route was found between those two places.", 422, "no_route")
    if resp.status_code != 200 or code != "Ok":
        raise UpstreamError(f"Routing service error ({code or resp.status_code}).")
    return [_parse_route(r, duration_factor) for r in data["routes"]]


def _detour_candidates(origin, dest, fastest: RawRoute):
    """Via-points pushed sideways from the middle of the fastest route."""
    mid = geo.interpolate_at(fastest.coords, fastest.cum_m, fastest.distance_m / 2)
    straight = geo.haversine_m(origin, dest)
    brg = geo.bearing_deg(origin, dest)
    for frac in (0.12, 0.22, 0.35):
        for side in (90, -90):
            yield geo.destination_point(mid, (brg + side) % 360, straight * frac)


def get_routes(origin: geo.LatLon, dest: geo.LatLon, duration_factor: float) -> list[RawRoute]:
    routes = fetch_routes([origin, dest], True, duration_factor)
    routes.sort(key=lambda r: r.duration_s)

    if len(routes) < WANTED_ROUTES:
        fastest = routes[0]
        samples = [geo.decimate(r.coords, 3000) for r in routes]
        tried = 0
        for via in _detour_candidates(origin, dest, fastest):
            if len(routes) >= WANTED_ROUTES or tried >= 6:
                break
            tried += 1
            try:
                cand = fetch_routes([origin, via, dest], False, duration_factor)[0]
            except ApiError as exc:
                log.info("detour via %s failed: %s", via, exc)
                continue
            if cand.distance_m > fastest.distance_m * MAX_DETOUR_RATIO:
                continue
            cand_sample = geo.decimate(cand.coords, 3000)
            if any(geo.overlap_fraction(cand_sample, s) > MAX_OVERLAP for s in samples):
                continue
            routes.append(cand)
            samples.append(cand_sample)
        routes.sort(key=lambda r: r.duration_s)
    return routes[:WANTED_ROUTES]
