const BASE = import.meta.env.VITE_API_BASE ?? '/api';

async function request(path, options) {
  const res = await fetch(BASE + path, options);
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* non-JSON error page */
  }
  if (!res.ok) throw new Error(data?.error?.message ?? `Request failed (${res.status}).`);
  return data;
}

export const geocode = (q, signal) => request(`/geocode?q=${encodeURIComponent(q)}`, { signal });

export const analyzeTrip = (payload, signal) =>
  request('/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    signal,
  });
