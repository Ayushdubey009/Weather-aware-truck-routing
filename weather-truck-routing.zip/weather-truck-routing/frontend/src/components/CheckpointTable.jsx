import { RiskBadge } from './RouteCard.jsx';
import { formatTime } from '../lib/format';

export default function CheckpointTable({ route, onFocus }) {
  return (
    <div className="panel">
      <h3>{route.name} checkpoints</h3>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Mile</th>
              <th>ETA</th>
              <th>Wind</th>
              <th>Rain</th>
              <th>Snow</th>
              <th>Risk</th>
            </tr>
          </thead>
          <tbody>
            {route.checkpoints.map((cp) => (
              <tr key={cp.index} onClick={() => onFocus({ lat: cp.lat, lon: cp.lon, key: `${route.id}-${cp.index}-${Date.now()}` })} title={cp.drivers.join('\n') || undefined}>
                <td>{Math.round(cp.mile)}</td>
                <td>{formatTime(cp.eta)}</td>
                <td>{cp.wind_mph.toFixed(0)} mph</td>
                <td>{cp.rain_in_hr.toFixed(2)}</td>
                <td>{cp.snow_in_hr.toFixed(1)}</td>
                <td><RiskBadge level={cp.risk_level} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="note">Rain and snow in inches/hour, sampled at the truck's ETA. Click a row to find it on the map.</p>
    </div>
  );
}
