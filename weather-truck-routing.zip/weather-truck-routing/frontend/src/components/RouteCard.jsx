import { LEVELS, ROUTE_COLORS, levelInfo } from '../lib/risk';
import { formatDuration, formatMiles, formatTime } from '../lib/format';

export function RiskBadge({ level }) {
  const info = levelInfo(level);
  return (
    <span className="badge" style={{ '--c': info.color }}>
      {info.label}
    </span>
  );
}

export default function RouteCard({ route, index, selected, onSelect }) {
  const s = route.summary;
  const total = route.distance_miles || 1;
  return (
    <button
      type="button"
      className={`route-card${selected ? ' selected' : ''}`}
      aria-pressed={selected}
      onClick={() => onSelect(route.id)}
      style={{ '--route': ROUTE_COLORS[index % ROUTE_COLORS.length] }}
    >
      <div className="route-head">
        <span className="swatch" />
        <strong>{route.name}</strong>
        {route.recommended && <span className="recommended">Recommended</span>}
        <span className="spacer" />
        <RiskBadge level={s.worst_level} />
      </div>
      <div className="route-stats">
        <span>{formatMiles(route.distance_miles)}</span>
        <span>{formatDuration(route.duration_minutes)}</span>
        <span>Arrive {formatTime(route.arrival)}</span>
      </div>
      <div className="mix" role="img" aria-label="Share of route miles by weather risk">
        {LEVELS.map((l) => {
          const miles = s.miles_by_level[l.key];
          return miles > 0 ? <i key={l.key} style={{ width: `${(miles / total) * 100}%`, background: l.color }} /> : null;
        })}
      </div>
      <div className="route-risk">
        <span>{s.no_travel_miles > 0 ? `${Math.round(s.no_travel_miles)} mi No Travel · ` : ''}{Math.round(s.severe_miles)} mi Severe</span>
        <span>{Math.round(s.high_miles)} mi High</span>
        <span>Avg risk {s.avg_risk.toFixed(2)}</span>
      </div>
    </button>
  );
}
