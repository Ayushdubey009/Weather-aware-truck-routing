import { useEffect, useRef } from 'react';
import L from 'leaflet';
import { ROUTE_COLORS, levelInfo } from '../lib/risk';
import { formatTime } from '../lib/format';

const MILE_M = 1609.344;

function checkpointTooltip(cp, route) {
  const el = document.createElement('div');
  const lines = [
    `${route.name} · mile ${Math.round(cp.mile)}`,
    `ETA ${formatTime(cp.eta)}`,
    `Wind ${cp.wind_mph.toFixed(0)} mph · Rain ${cp.rain_in_hr.toFixed(2)} in/hr · Snow ${cp.snow_in_hr.toFixed(1)} in/hr`,
    `Risk: ${cp.risk_label}`,
    ...cp.drivers,
  ];
  lines.forEach((text, i) => {
    const d = document.createElement('div');
    d.textContent = text;
    if (i === 0 || i === 3) d.style.fontWeight = '600';
    el.appendChild(d);
  });
  return el;
}

function pinIcon(letter) {
  return L.divIcon({ className: 'pin', html: `<span>${letter}</span>`, iconSize: [28, 28], iconAnchor: [14, 14] });
}

export default function MapView({ result, selectedId, onSelect, heatPoints, heatOn, heatHour, focus }) {
  const elRef = useRef(null);
  const mapRef = useRef(null);
  const routeLayer = useRef(null);
  const heatLayer = useRef(null);
  const heatRenderer = useRef(null);
  const circles = useRef([]);

  // --- one-time map setup -------------------------------------------------
  useEffect(() => {
    const map = L.map(elRef.current, { preferCanvas: true, zoomSnap: 0.5 }).setView([39.5, -98.35], 4);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
      attribution: '&copy; OpenStreetMap contributors',
    }).addTo(map);
    // The heat layer lives in its own pane under the route lines; CSS blurs it into a smooth surface.
    map.createPane('heat').style.zIndex = 350;
    heatRenderer.current = L.canvas({ pane: 'heat', padding: 0.3 });
    routeLayer.current = L.layerGroup().addTo(map);
    heatLayer.current = L.layerGroup();
    mapRef.current = map;
    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // --- routes, checkpoints, endpoints --------------------------------------
  useEffect(() => {
    const group = routeLayer.current;
    if (!mapRef.current || !group) return;
    group.clearLayers();
    if (!result) return;

    const ordered = [...result.routes].sort((a, b) => (a.id === selectedId) - (b.id === selectedId));
    ordered.forEach((route) => {
      const idx = result.routes.findIndex((r) => r.id === route.id);
      const selected = route.id === selectedId;
      const path = route.segments.flatMap((s) => s.path);

      if (selected) {
        L.polyline(path, { color: '#ffffff', weight: 11, opacity: 0.95, interactive: false }).addTo(group);
        route.segments.forEach((seg) =>
          L.polyline(seg.path, { color: levelInfo(seg.level).color, weight: 6, opacity: 1, interactive: false }).addTo(group),
        );
      } else {
        L.polyline(path, { color: ROUTE_COLORS[idx % ROUTE_COLORS.length], weight: 4, opacity: 0.65, dashArray: '9 7', interactive: false }).addTo(group);
        // wide invisible line = easy click target
        L.polyline(path, { weight: 18, opacity: 0, interactive: true }).on('click', () => onSelect(route.id)).addTo(group);
      }

      route.checkpoints.forEach((cp) => {
        const info = levelInfo(cp.risk_level);
        const marker = L.circleMarker([cp.lat, cp.lon], {
          radius: selected ? 6.5 : 3.5,
          color: selected ? '#ffffff' : info.color,
          weight: selected ? 2 : 1,
          fillColor: info.color,
          fillOpacity: selected ? 1 : 0.85,
        });
        marker.bindTooltip(checkpointTooltip(cp, route), { direction: 'top', sticky: true });
        if (!selected) marker.on('click', () => onSelect(route.id));
        marker.addTo(group);
      });
    });

    [[result.origin, 'A'], [result.destination, 'B']].forEach(([place, letter]) => {
      const m = L.marker([place.lat, place.lon], { icon: pinIcon(letter), zIndexOffset: 1000 });
      const tip = document.createElement('div');
      tip.textContent = place.label;
      m.bindTooltip(tip, { direction: 'top', offset: [0, -12] });
      m.addTo(group);
    });
  }, [result, selectedId, onSelect]);

  // --- fit the map to a new result (not on every route selection) -----------
  useEffect(() => {
    if (!mapRef.current || !result) return;
    const pts = result.routes.flatMap((r) => r.segments.flatMap((s) => s.path));
    mapRef.current.fitBounds(L.latLngBounds(pts), { padding: [40, 40] });
  }, [result]);

  // --- heatmap circles (rebuilt only when the trip changes) ------------------
  useEffect(() => {
    const group = heatLayer.current;
    if (!group) return;
    group.clearLayers();
    circles.current = [];
    if (!result) return;
    const radius = Math.max(result.interval_miles * 0.85, 10) * MILE_M;
    heatPoints.forEach((point) => {
      const circle = L.circle([point.lat, point.lon], {
        pane: 'heat',
        renderer: heatRenderer.current,
        radius,
        stroke: false,
        interactive: false,
        fillOpacity: 0.5,
      });
      circle.addTo(group);
      circles.current.push({ circle, point });
    });
  }, [result, heatPoints]);

  // --- heatmap restyle on slider move (cheap: just setStyle) ------------------
  useEffect(() => {
    const map = mapRef.current;
    const group = heatLayer.current;
    if (!map || !group) return;
    if (heatOn && !map.hasLayer(group)) group.addTo(map);
    if (!heatOn && map.hasLayer(group)) map.removeLayer(group);
    circles.current.forEach(({ circle, point }) => {
      const level = point.forecast.levels[heatHour] ?? 0;
      circle.setStyle({ fillColor: levelInfo(level).color, fillOpacity: level === 0 ? 0.3 : 0.6 });
    });
  }, [heatOn, heatHour, heatPoints, result]);

  // --- pan to a clicked checkpoint --------------------------------------------
  useEffect(() => {
    if (mapRef.current && focus) {
      mapRef.current.flyTo([focus.lat, focus.lon], Math.max(mapRef.current.getZoom(), 9), { duration: 0.7 });
    }
  }, [focus]);

  return <div ref={elRef} className="map" role="application" aria-label="Route map" />;
}
