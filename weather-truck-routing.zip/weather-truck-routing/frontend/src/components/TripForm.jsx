import { useState } from 'react';
import PlaceInput from './PlaceInput.jsx';
import { defaultDeparture } from '../lib/format';

const EXAMPLES = [
  { label: 'Chicago → Denver', origin: 'Chicago, IL', destination: 'Denver, CO' },
  { label: 'Seattle → Billings', origin: 'Seattle, WA', destination: 'Billings, MT' },
  { label: 'Dallas → Atlanta', origin: 'Dallas, TX', destination: 'Atlanta, GA' },
];

const toSpec = ({ text, place }) =>
  place ? { lat: place.lat, lon: place.lon, label: place.label } : { query: text.trim() };

export default function TripForm({ onSubmit, loading }) {
  const [origin, setOrigin] = useState({ text: '', place: null });
  const [destination, setDestination] = useState({ text: '', place: null });
  const [departure, setDeparture] = useState(defaultDeparture);
  const [load, setLoad] = useState(40000);
  const [interval, setInterval] = useState(25);

  const ready = origin.text.trim() && destination.text.trim() && departure && load !== '';

  function submit(e) {
    e.preventDefault();
    if (!ready || loading) return;
    onSubmit({
      origin: toSpec(origin),
      destination: toSpec(destination),
      departure: new Date(departure).toISOString(),
      load_weight_lb: Number(load),
      interval_miles: Number(interval),
    });
  }

  return (
    <form className="panel form" onSubmit={submit}>
      <PlaceInput id="origin" label="Origin" placeholder="City or address" value={origin} onChange={setOrigin} />
      <PlaceInput id="destination" label="Destination" placeholder="City or address" value={destination} onChange={setDestination} />
      <div className="row">
        <div className="field">
          <label htmlFor="departure">Departure</label>
          <input id="departure" type="datetime-local" value={departure} onChange={(e) => setDeparture(e.target.value)} required />
        </div>
        <div className="field">
          <label htmlFor="load">Load weight (lb)</label>
          <input id="load" type="number" min="0" max="150000" step="500" value={load} onChange={(e) => setLoad(e.target.value)} required />
        </div>
      </div>
      <div className="field">
        <label htmlFor="interval">Weather checkpoint every</label>
        <div className="segmented" role="radiogroup" aria-label="Checkpoint spacing">
          {[10, 25, 50].map((v) => (
            <button
              key={v}
              type="button"
              role="radio"
              aria-checked={interval === v}
              className={interval === v ? 'on' : ''}
              onClick={() => setInterval(v)}
            >
              {v} mi
            </button>
          ))}
        </div>
      </div>
      <button className="primary" type="submit" disabled={!ready || loading}>
        {loading ? 'Checking weather along 3 routes…' : 'Find safest route'}
      </button>
      <div className="examples">
        <span>Try:</span>
        {EXAMPLES.map((ex) => (
          <button
            key={ex.label}
            type="button"
            className="link"
            onClick={() => {
              setOrigin({ text: ex.origin, place: null });
              setDestination({ text: ex.destination, place: null });
            }}
          >
            {ex.label}
          </button>
        ))}
      </div>
    </form>
  );
}
