import { useEffect, useState } from 'react';
import { geocode } from '../api';

// value = { text, place }, where place is a chosen suggestion ({label, lat, lon}) or null.
export default function PlaceInput({ id, label, value, onChange, placeholder }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const text = value.text.trim();
    if (value.place || text.length < 3) {
      setItems([]);
      return undefined;
    }
    const ctrl = new AbortController();
    const timer = setTimeout(async () => {
      setBusy(true);
      try {
        const data = await geocode(text, ctrl.signal);
        setItems(data.results);
      } catch (err) {
        if (err.name !== 'AbortError') setItems([]);
      } finally {
        if (!ctrl.signal.aborted) setBusy(false);
      }
    }, 450); // Nominatim asks for polite request rates
    return () => {
      clearTimeout(timer);
      ctrl.abort();
    };
  }, [value.text, value.place]);

  return (
    <div className="field place">
      <label htmlFor={id}>{label}</label>
      <input
        id={id}
        value={value.text}
        placeholder={placeholder}
        autoComplete="off"
        onChange={(e) => {
          onChange({ text: e.target.value, place: null });
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onBlur={() => setTimeout(() => setOpen(false), 120)}
      />
      {busy && <span className="hint">Searching…</span>}
      {open && items.length > 0 && (
        <ul className="suggestions" role="listbox">
          {items.map((it) => (
            <li
              key={`${it.lat},${it.lon}`}
              role="option"
              onMouseDown={() => {
                onChange({ text: it.label, place: it });
                setOpen(false);
              }}
            >
              {it.label}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
