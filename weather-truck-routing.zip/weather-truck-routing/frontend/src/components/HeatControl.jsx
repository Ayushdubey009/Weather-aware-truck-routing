import { useMemo } from 'react';
import { LEVELS, levelInfo } from '../lib/risk';
import { formatTime } from '../lib/format';

export default function HeatControl({ result, points, on, setOn, hour, setHour }) {
  const when = new Date(new Date(result.forecast_start).getTime() + hour * 3600_000);
  const worst = useMemo(() => points.reduce((m, p) => Math.max(m, p.forecast.levels[hour] ?? 0), 0), [points, hour]);
  const worstInfo = levelInfo(worst);

  return (
    <div className="heat-control">
      <div className="heat-top">
        <label className="switch">
          <input type="checkbox" checked={on} onChange={(e) => setOn(e.target.checked)} />
          Weather heatmap
        </label>
        <span className="heat-when">
          {hour === 0 ? 'Departure' : `Departure + ${hour}h`} · {formatTime(when.toISOString())}
        </span>
        <span className="badge" style={{ '--c': worstInfo.color }} title="Worst conditions on any route at this hour">
          Worst: {worstInfo.label}
        </span>
      </div>
      <input
        type="range"
        min="0"
        max={result.forecast_hours}
        step="1"
        value={hour}
        disabled={!on}
        onChange={(e) => setHour(Number(e.target.value))}
        aria-label="Forecast hours after departure"
      />
      <div className="ticks">
        {[0, 12, 24, 36, 48].map((h) => (
          <span key={h}>{h}h</span>
        ))}
      </div>
      <div className="legend">
        {LEVELS.map((l) => (
          <span key={l.key}>
            <i style={{ background: l.color }} />
            {l.label}
          </span>
        ))}
      </div>
    </div>
  );
}
