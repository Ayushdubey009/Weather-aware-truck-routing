import { useCallback, useMemo, useRef, useState } from 'react';
import { analyzeTrip } from './api';
import TripForm from './components/TripForm.jsx';
import RouteCard from './components/RouteCard.jsx';
import CheckpointTable from './components/CheckpointTable.jsx';
import MapView from './components/MapView.jsx';
import HeatControl from './components/HeatControl.jsx';
import { buildHeatPoints } from './lib/format';

export default function App() {
  const [result, setResult] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [heatOn, setHeatOn] = useState(true);
  const [heatHour, setHeatHour] = useState(0);
  const [focus, setFocus] = useState(null);
  const abortRef = useRef(null);

  const heatPoints = useMemo(() => (result ? buildHeatPoints(result) : []), [result]);
  const selected = result?.routes.find((r) => r.id === selectedId) ?? null;
  const onSelect = useCallback((id) => setSelectedId(id), []);

  async function plan(payload) {
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setLoading(true);
    setError('');
    try {
      const data = await analyzeTrip(payload, ctrl.signal);
      setResult(data);
      setSelectedId(data.recommendation.route_id);
      setHeatHour(0);
      setFocus(null);
    } catch (err) {
      if (err.name !== 'AbortError') setError(err.message);
    } finally {
      if (abortRef.current === ctrl) setLoading(false);
    }
  }

  // Cards listed best-first; colours/letters stay tied to the original (fastest-first) order.
  const ranked = result ? [...result.routes].sort((a, b) => a.rank - b.rank) : [];

  return (
    <div className="app">
      <header className="topbar">
        <h1>Weather-aware truck routing</h1>
        <p>Compare three routes by forecast wind, rain and snow at the time you'll actually be there.</p>
      </header>

      <aside className="sidebar">
        <TripForm onSubmit={plan} loading={loading} />

        {error && (
          <div className="panel error" role="alert">
            <strong>Couldn't plan that trip.</strong> {error}
          </div>
        )}

        {result && (
          <>
            <div className="panel recommendation">
              <h3>Recommendation</h3>
              <ul>
                {result.recommendation.reasons.map((r) => (
                  <li key={r}>{r}</li>
                ))}
              </ul>
              <p className="note">
                Ranked by fewest Severe miles, then fewest High miles, lowest average risk, shortest time. A route with
                No Travel conditions always ranks last.
              </p>
            </div>

            <div className="routes">
              {ranked.map((route) => (
                <RouteCard
                  key={route.id}
                  route={route}
                  index={result.routes.indexOf(route)}
                  selected={route.id === selectedId}
                  onSelect={onSelect}
                />
              ))}
            </div>

            {selected && <CheckpointTable route={selected} onFocus={setFocus} />}
          </>
        )}
      </aside>

      <main className="stage">
        <MapView
          result={result}
          selectedId={selectedId}
          onSelect={onSelect}
          heatPoints={heatPoints}
          heatOn={heatOn}
          heatHour={heatHour}
          focus={focus}
        />
        {!result && !loading && <div className="empty">Enter a trip to see routes, checkpoints and the forecast heatmap.</div>}
        {loading && <div className="empty busy">Fetching routes and hourly forecasts…</div>}
        {result && <HeatControl result={result} points={heatPoints} on={heatOn} setOn={setHeatOn} hour={heatHour} setHour={setHeatHour} />}
      </main>
    </div>
  );
}
