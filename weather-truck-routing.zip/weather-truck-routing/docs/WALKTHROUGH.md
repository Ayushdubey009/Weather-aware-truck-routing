# Loom walkthrough script (aim for ~7 minutes)

**0:00 – Problem & stack (30 s).** Truck driver, three routes, weather at the time you'll be there, load-aware. React +
Leaflet front end, Django API, OSRM / Open-Meteo / Nominatim (all key-less).

**0:30 – Live demo (2 min).**
1. Click the "Chicago → Denver" example, keep load 40,000 lb, 25-mile checkpoints, **Find safest route**.
2. Point out: three routes on the map, selected route coloured by risk, recommendation reasons, route cards
   (miles Severe/High, average risk, ETA).
3. Hover a checkpoint (ETA, wind/rain/snow, risk). Click a table row → map flies there.
4. Change load to 85,000 lb and re-run to show the load rules changing risk/recommendation.

**2:30 – Heatmap (1 min).** Drag the 0–48 h slider; explain it only restyles data already in memory (smooth, no
requests) and the "Worst" badge. Toggle it off/on.

**3:30 – Logic (2 min)** – open `risk.py`, `scoring.py`.
* Threshold table + load rules, boundary decisions.
* ETA-based sampling: `analysis.py` → checkpoint ETA → `weather.py` hour lookup.
* Ranking order; why No Travel is a gate; rounding to avoid noise flips.

**5:30 – Engineering (1 min).** Providers injected → tests run offline (38 tests). Batched + cached weather; 3-route
fallback when OSRM returns fewer; checkpoint cap; error handling.

**6:30 – Trade-offs & next steps (30 s).** Car profile vs truck routing, hours-of-service, gusts, 2-D weather grid,
user time zone at origin.
